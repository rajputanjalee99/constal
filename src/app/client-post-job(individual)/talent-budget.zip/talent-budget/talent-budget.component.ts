import { Component, OnInit } from '@angular/core';
import { Options } from '@angular-slider/ngx-slider';
import { Service } from "../../service/service.service";
import {MatSnackBar} from '@angular/material/snack-bar';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router, CanActivate } from '@angular/router';

@Component({
  selector: 'app-talent-budget',
  templateUrl: './talent-budget.component.html',
  styleUrls: ['./talent-budget.component.scss']
})
export class TalentBudgetComponent implements OnInit {

value: number = 30;
  options: Options = {
    floor: 0,
    ceil: 80,
    step: 10,
    showTicks: true,
    showTicksValues: true
  };

  form: FormGroup;
  isLoading = false;
  jobDetail = null;
  totalTalents = [];
  currentIndex = 0;
  talentLocation = "remotely";
  skills: any;
  tool_skills: any;
  selectedSpecialities = [];

  sector_list = [];

  constructor(public router: Router,private service : Service,private _snackBar: MatSnackBar,private fb: FormBuilder) {
    
    const job_id = localStorage.getItem("job_id");

    if(!job_id){
        this.router.navigate(['getting-started']);
        this.service.showErrorMessage({
          message : "Please complete 1 step first"
        })
    }
  }

  ngOnInit(): void {
    this.getJobDetail();
    this.getSkillsData();
    this.getDisciplineSectors();
  }

  getDisciplineSectors(){
    console.log("discipline ======== ",localStorage.getItem("discipline"))
    this.service.getTalentDisciplineSectors(localStorage.getItem("discipline")).subscribe(res => {
      this.sector_list = res.sectors;
      console.log('sector list res ======== ',res);
    },(error) => {
      this.service.handleError(error);
    })
  }

  getSkillsData(){
    this.service.getSkillsData().subscribe(res => {
      console.log(res);
      this.skills = res.topSkills;
      this.tool_skills = res.technologySkills;
    },(error) => {
      this.service.handleError(error);

    })
  }

  getJobDetail(){

    if(localStorage.getItem("talents")){

      this.totalTalents = JSON.parse(localStorage.getItem("talents"))

    }


    // const job_id = localStorage.getItem("job_id");
    let job_id;
		if(localStorage.getItem("reuse_job_id")){
			job_id = localStorage.getItem("reuse_job_id");
		}else{
			job_id = localStorage.getItem("job_id");
		}
    if (job_id && job_id!=undefined) {
      this.service.getJobDetail(job_id).subscribe(async res => {
        this.isLoading = false
        this.jobDetail = res.details;
        console.log("jobDetail response dd ================== ",res)
        for (let i = 1; i <= res.details.total_talents_required; i++) {
         // this.totalTalents.push(i);
        }
        console.log("total talents ================== ",this.totalTalents)
        // this.form.setValue({
        //   title: res.details && res.details.title ? res.details.title : "",
        //   description: res.details && res.details.description ? res.details.description : "",
        // });

        // if(res.details && res.details.visibility){
        //   this.visibility = res.details.visibility;
        // }

        // if(res.details && res.details.co_workers.length){
        //   this.co_workers = res.details.co_workers
        // }

        // if(res.details && res.details.project_files.length){
        //   this.files = res.details.project_files
        // }

      },(err) => {
        this.isLoading = false
        this.service.handleError(err)
        console.log(err)
      })
    }else{
      this.jobDetail = null;
    }
  }

  chooseSkills(skill_id){
    this.totalTalents[this.currentIndex].skills.push(skill_id);
    // this.totalTalents[index]['specialities'] = this.selectedSpecialities
    console.log("speciality_ids =============== ",this.selectedSpecialities)
  }

  removeSkills(skill_id){

    let index2 = this.totalTalents[this.currentIndex].skills.findIndex((item) => {
      return item == skill_id
    });
    this.totalTalents[this.currentIndex].skills.splice(index2,1)
  }

  chooseToolSkills(skill_id){
    this.totalTalents[this.currentIndex].tool_skills.push(skill_id);
    // this.totalTalents[index]['specialities'] = this.selectedSpecialities
    console.log("speciality_ids =============== ",this.selectedSpecialities)
  }

  removeToolSkills(skill_id){

    let index2 = this.totalTalents[this.currentIndex].tool_skills.findIndex((item) => {
      return item == skill_id
    });
    this.totalTalents[this.currentIndex].tool_skills.splice(index2,1)
  }

  saveTalentDetails(){
    const job_id = localStorage.getItem("job_id");

    // console.log(this.clientSpecialityDigitalServices);
    // console.log(this.clientSpecialityTraditionalServices);
    // const diArr = [];
    // const traArr = [];
    // this.clientSpecialityTraditionalServices.map(item => {
    //   if(item.flag){
    //       traArr.push(item._id);
    //   }
    // } )

    // this.clientSpecialityDigitalServices.map(item => {
    //   if(item.flag){
    //       diArr.push(item._id);
    //   }
    // })

    // this.totalTalents[this.currentIndex].digital_service = diArr;
    // this.totalTalents[this.currentIndex].traditional_service = traArr;
    
    this.totalTalents[this.currentIndex].job_id = job_id;
    
    this.service.saveTalentDetails(this.totalTalents[this.currentIndex]).subscribe(async res => {

      this.totalTalents[this.currentIndex].job_talent_id = res.resp._id;
      localStorage.setItem('talents',JSON.stringify(this.totalTalents));

      this.totalTalents[this.currentIndex].specialities_new = [];

      // this.getJobSpecialities();

      if(this.totalTalents.length - 1 == this.currentIndex){
        // this.router.navigate(["review-post"])
        this.router.navigate(["project-title"])
      }else{
        this.currentIndex = this.currentIndex + 1;
      }
      this.isLoading = false;
      // this.service.showErrorMessage({
      //   message:"Member added"
      // })

    },(err) => {

      this.isLoading = false;
      this.service.handleError(err)

    })
    
  }

}
